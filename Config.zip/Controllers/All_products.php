<?php namespace App\Controllers;

class All_products extends BaseController
{

	
	public function index()
	{	
		return view('all_products');
	}

}