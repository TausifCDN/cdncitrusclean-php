<?php include 'header.php';?>
<h1>Setting</h1>
<?php include 'footer.php';?>
