<?php include(APPPATH."Views/__partial/__header.php"); ?> 
<section class="page_header banner-inner main_resi">
    <div class="container">
        <div class="banner-descrptions2" style="text-align: center;color: #fff;padding: 8% 0px;margin: 0px;">
             <h1>Wholesale</h1>
             <p>Wholesale</p>
        </div>
    </div>
</section>
<section class="About-us">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="about-info">
                    <!--<p>Wholesale</p>-->

                    <h2 class="heading-inner-main" style="text-align: left;">Wholesale</h2>
                    
                
                    
                    
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    ol li {
        padding-left: 5px;
    }
    ol{
        padding-left: 19px;
    }
</style>
<?php include(APPPATH."Views/__partial/__footer.php"); ?> 