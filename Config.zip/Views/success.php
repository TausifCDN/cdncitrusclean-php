<?php include(APPPATH."Views/__partial/__header.php");?> 

<div class="container">
	<h3>THANK YOU</h3>
	<P>Your meeting has been scheduled successfully.</P>
</div>

<?php include(APPPATH."Views/__partial/__footer.php");?>  
<?php include(APPPATH."Views/__partial/__js.php");?>