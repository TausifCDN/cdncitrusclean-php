<?php include(APPPATH."Views/__partial/__header.php"); ?> 
    <!--banner start-->
        <section class="banner-inner">
        <div class="container">
            <div class="banner-descrptions2 mobiles-view">
                <h6>Complete Product Range</h6>
                <p>Description goes here, this is the section where the product description along with the importanat details would always appear</p>                
            </div>
        </div>
        <div class="banner-pic2" style=" background: url(<?=base_url();?>/assets/images/re.png);">
            </div>
        <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="banner-descrptions2 desktop-view">
                     <h1>Complete Product Range</h1>
                     <p>Description goes here, this is the section where the product description along with the importanat details would always appear.</p>
                   
                </div>
            </div>
            
        </div>
        </div>
    </section>
    <!--About us-->
    <section class="Our-package" style="background: #fff">
        <div class="container">
          <br>
          <h2 >All Products</h2>
          <br>
        <div class="row form-group">
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>
            <div class="col-md-3 form-group">
              <div class="">
                    <div class="seller-select_link">
                        <div class="seller-hover-overlay">
                          <img class="img-fluid w-100" src="http://192.168.30.149/cdncc/frontend/../uploads/product1.png">
                          <div class="row">
                            <div class="col-md-12 text-center">
                              <h4 class="mb-3 mt-2">Product 1</h4>
                              <p><a href="#" class="more-btns">Buy Now | $100</a></p>
                             <p><a href="#" class="learn-btn">Learn More </a></p>
                            </div>
                          </div>                                          
                      </div>
                    </div>
                </div>            
            </div>

         
        </div>
    </div>
    </section>



    <?php include(APPPATH."Views/__partial/__available.php");?> 
    <?php include(APPPATH."Views/__partial/__testimonial.php");?> 

<?php include(APPPATH."Views/__partial/__footer.php"); ?> 