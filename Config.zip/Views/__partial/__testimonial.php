<!--Our Testimonial-->
<section class="Our-testimonial">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2 class="heading-inner-main">What do families think of CDN Citrus Clean?</h2>
                <script src="https://apps.elfsight.com/p/platform.js" defer></script>
                <div class="elfsight-app-287693bd-40e2-446d-adc2-36bd6fe0a2f3"></div>
              	 <!--<div class="owl-carousel owl-theme" id="carousel_reviews">
                  <div class="testimonial-main">
                    <div class="author-inner">
                      <img src="<?= base_url() ?>/assets/images/test1.png">
                      <ul>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                      </ul>
                    </div>
                    <div class="author-info">
                      <h3>Ruben Dokidis</h3>
                      <p>Lorem Ipsum Dolor Set Sed nisi. Nulla quis sem at nibh elementum imperdietla quis sem at. Nulla quis sem at nibh elementum</p>
                    </div>
                  </div>
                  <div class="testimonial-main">
                    <div class="author-inner">
                      <img src="<?= base_url() ?>/assets/images/test2.png">
                      <ul>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                      </ul>
                    </div>
                    <div class="author-info">
                      <h3>Gustavo Curtis</h3>
                      <p>Lorem Ipsum Dolor Set Sed nisi. Nulla quis sem at nibh elementum imperdietla quis sem at. Nulla quis sem at nibh elementum</p>
                    </div>
                  </div>
                  <div class="testimonial-main">
                    <div class="author-inner">
                      <img src="<?= base_url() ?>/assets/images/test3.png">
                      <ul>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                      </ul>
                    </div>
                    <div class="author-info">
                      <h3>Leo Siphron</h3>
                      <p>Lorem Ipsum Dolor Set Sed nisi. Nulla quis sem at nibh elementum imperdietla quis sem at. Nulla quis sem at nibh elementum</p>
                    </div>
                  </div>
                  <div class="testimonial-main">
                    <div class="author-inner">
                      <img src="<?= base_url() ?>/assets/images/test4.png">
                      <ul>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                      </ul>
                    </div>
                    <div class="author-info">
                      <h3>Maren Dorwart</h3>
                      <p>Lorem Ipsum Dolor Set Sed nisi. Nulla quis sem at nibh elementum imperdietla quis sem at. Nulla quis sem at nibh elementum</p>
                    </div>
                  </div>
                  <div class="testimonial-main">
                    <div class="author-inner">
                      <img src="<?= base_url() ?>/assets/images/test5.png">
                      <ul>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                        <li><img src="<?= base_url() ?>/assets/images/star.png"></li>
                      </ul>
                    </div>
                    <div class="author-info">
                      <h3>Nolan Dias</h3>
                      <p>Lorem Ipsum Dolor Set Sed nisi. Nulla quis sem at nibh elementum imperdietla quis sem at. Nulla quis sem at nibh elementum</p>
                    </div>
                  </div>-->
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        
    </div>
</section>
