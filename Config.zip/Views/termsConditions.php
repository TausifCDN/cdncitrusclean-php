<?php include(APPPATH."Views/__partial/__header.php"); ?> 
<section class="page_header banner-inner main_resi">
    <div class="container">
        <div class="banner-descrptions2">
             <h1 style="text-align: center;color: #fff;padding: 8% 0px;font-size: 6vw;margin: 0px;">Terms & Conditions</h1>
        </div>
    </div>
</section>
<section class="About-us">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="about-info">
                    
                    <h2 class="heading-inner-main" style="text-align: left;">Terms & Conditions</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    
                    
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    ol li {
        padding-left: 5px;
    }
    ol{
        padding-left: 19px;
    }
</style>
<?php include(APPPATH."Views/__partial/__footer.php"); ?> 