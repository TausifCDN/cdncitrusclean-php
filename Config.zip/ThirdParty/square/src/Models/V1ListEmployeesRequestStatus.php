<?php

declare(strict_types=1);

namespace Square\Models;

class V1ListEmployeesRequestStatus
{
    public const ACTIVE = 'ACTIVE';

    public const INACTIVE = 'INACTIVE';
}
