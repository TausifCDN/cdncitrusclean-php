<?php

declare(strict_types=1);

namespace Square\Models;

class V1ListSettlementsRequestStatus
{
    public const SENT = 'SENT';

    public const FAILED = 'FAILED';
}
