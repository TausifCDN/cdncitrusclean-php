<?php

declare(strict_types=1);

namespace Square\Models;

class V1EmployeeStatus
{
    public const ACTIVE = 'ACTIVE';

    public const INACTIVE = 'INACTIVE';
}
