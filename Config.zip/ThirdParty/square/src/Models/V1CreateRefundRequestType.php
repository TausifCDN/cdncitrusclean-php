<?php

declare(strict_types=1);

namespace Square\Models;

class V1CreateRefundRequestType
{
    public const FULL = 'FULL';

    public const PARTIAL = 'PARTIAL';
}
