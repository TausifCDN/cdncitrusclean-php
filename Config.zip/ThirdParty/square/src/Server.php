<?php

declare(strict_types=1);

namespace Square;

/**
 * Baseurl aliases
 */
class Server
{
    public const DEFAULT_ = 'default';
}
