<div style="background-color:#f2f2f2">
	<table width="550px" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
		<tbody>
			<tr style="background-color: #f2f2f2;">
				<td width="100%" height="40" style="border-collapse:collapse"></td>
			</tr>
			<tr style="width:100%;text-align:center;">
				<td style="padding-top: 30px;padding-bottom: 15px;font-size:25px;font-weight:700;text-align:center;">CDN Citrus Clean</td>
			</tr>
	
			<tr style="float:left;padding:0px 30px;clear:both">
				<td style="font-weight:bold">Name: </td>
				<td><?php echo $name;?></td>
			</tr>
			<tr style="float:left;padding:0px 30px;clear:both">
				<td style="font-weight:bold">email: </td>
				<td><?php echo $email;?></td>
			</tr>
			<tr style="float:left;padding:0px 30px;clear:both">
				<td style="font-weight:bold">Company: </td>
				<td><?php echo $company;?></td>
			</tr>
			<tr style="float:left;padding:0px 30px;clear:both">
				<td style="font-weight:bold">Subject: </td>
				<td><?php echo $subject;?></td>
			</tr>
			<tr style="float:left;padding:0px 30px;clear:both">
				<td style="font-weight:bold">Message: </td>
				<td><?php echo $message;?></td>
			</tr>
		
			<tr>
				<td width="100%" height="20" style="border-collapse:collapse"></td>
			</tr>
			
			<tr>
				<td width="100%" height="25" style="border-collapse:collapse"></td>
			</tr>
			<tr style="float:left;padding:15px 30px 0px;clear:both;font-weight:bold">
				<td>Thanks,</td>
			</tr>
			<tr style="float:left;padding:0px 30px;clear:both">
				<td></td>
			</tr>
			<tr style="float:left;padding:0px 30px;clear:both">
				<td><a href="<?php echo base_url();?>">www.cdncitrusclean.com</a></td>
			</tr>
			<tr>
				<td width="100%" height="40" style="border-collapse:collapse"></td>
			</tr>
			<tr style="padding:0px 30px;width:100%;background-color:#f2f2f2">
				<td style="padding:30px 0px;font-size:11px;text-align:center">
					© <?php echo date('Y');?> CDN Citrus Clean.
				</td>
			</tr>
		</tbody>
	</table>
</div>