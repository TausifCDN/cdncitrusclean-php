<?php
namespace othernamespace;

class Foo
{
    public $name;

    public function __construct($name)
    {
        $this->name = $name;
    }
}
?>
