<?php
class Contact
{
    public $name;

    /**
     * @var Address
     */
    public $address;
}
?>
