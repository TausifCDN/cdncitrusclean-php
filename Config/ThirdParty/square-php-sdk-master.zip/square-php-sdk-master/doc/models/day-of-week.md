
# Day of Week

Indicates the specific day  of the week.

## Enumeration

`DayOfWeek`

## Fields

| Name | Description |
|  --- | --- |
| `SUN` | Sunday |
| `MON` | Monday |
| `TUE` | Tuesday |
| `WED` | Wednesday |
| `THU` | Thursday |
| `FRI` | Friday |
| `SAT` | Saturday |

