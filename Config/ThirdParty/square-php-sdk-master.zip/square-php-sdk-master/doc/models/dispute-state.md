
# Dispute State

The list of possible dispute states.

## Enumeration

`DisputeState`

## Fields

| Name |
|  --- |
| `UNKNOWN_STATE` |
| `INQUIRY_EVIDENCE_REQUIRED` |
| `INQUIRY_PROCESSING` |
| `INQUIRY_CLOSED` |
| `EVIDENCE_REQUIRED` |
| `PROCESSING` |
| `WON` |
| `LOST` |
| `ACCEPTED` |
| `WAITING_THIRD_PARTY` |

