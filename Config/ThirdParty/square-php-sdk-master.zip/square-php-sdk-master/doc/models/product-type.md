
# Product Type

## Enumeration

`ProductType`

## Fields

| Name |
|  --- |
| `TERMINAL_API` |

