
# Card Prepaid Type

Indicates a card's prepaid type, such as `NOT_PREPAID` or `PREPAID`.

## Enumeration

`CardPrepaidType`

## Fields

| Name |
|  --- |
| `UNKNOWN_PREPAID_TYPE` |
| `NOT_PREPAID` |
| `PREPAID` |

