
# Loyalty Account Mapping Type

The type of mapping.

## Enumeration

`LoyaltyAccountMappingType`

## Fields

| Name | Description |
|  --- | --- |
| `PHONE` | The loyalty account is mapped by phone. |

